package com.example.myrecyclerviewdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);

        List<Item> items = new ArrayList<Item>();
        items.add(new Item("Game 1", 5, 6, 120));
        items.add(new Item("Game 2", 3, 4, 20));
        items.add(new Item("Game 3",2, 4, 30));
        items.add(new Item("Game 4",3, 5, 10));
        items.add(new Item("Game 5",6, 6, 200));
        items.add(new Item("Game 6",2,6, 13));
        items.add(new Item("Game 7",1,2, 25));
        items.add(new Item("Game 8",2, 5, 30));
        items.add(new Item("Game 9",3, 6, 500));
        items.add(new Item("Game 10",4, 5, 60));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new MyAdapter(getApplicationContext(),items));

    }
}