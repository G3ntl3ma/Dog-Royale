package com.example.myrecyclerviewdemo;

public class Item {

    String name;
    int currentPlayers;
    int maxPlayers;

    int timeSeconds;

    public Item(String name, int currentPlayers, int maxPlayers, int timeSeconds) {
        this.name = name;
        this.currentPlayers = currentPlayers;
        this.maxPlayers = maxPlayers;
        this.timeSeconds = timeSeconds;
    }

    public String getName() {
        return name;
    }

    public int getCurrentPlayers() {
        return currentPlayers;
    }

    public void setCurrentPlayers(int currentPlayers) {
        this.currentPlayers = currentPlayers;
    }

  public int getMaxPlayers() {
        return maxPlayers;
  }

    public int getTimeSeconds(){
        return timeSeconds;
    }
}
