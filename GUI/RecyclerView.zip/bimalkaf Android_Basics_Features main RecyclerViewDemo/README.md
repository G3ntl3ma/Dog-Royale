# MyRecyclerViewDemo

Simple RecyclerView app
Watch full tutorial on : https://youtu.be/TAEbP_ccjsk

![recylerview](https://user-images.githubusercontent.com/68380115/127163136-ae8f795e-3951-4d4d-824f-24689e3971d4.jpg)
